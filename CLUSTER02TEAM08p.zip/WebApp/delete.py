import sqlite3
con=sqlite3.connect('my_database.sqlite3')

cur=con.execute(f"SELECT * FROM userstable")

res=cur.fetchall()
print(res)
con.commit()